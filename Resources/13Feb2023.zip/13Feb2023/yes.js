// Values
// Values

// 7 => int
// 8.1 => Float
// Number

// 'Anurag'
// "Anurag"
// String

// true or false
// Boolean values

// Null
// undefined

// Prmitive Datatype
// Single value

// Non - Primitive values => Multi values
// array => [] => index
// Object => {} => Key:Value

// ["A", "B", "C", "D", "E", "F","G"];
// {}

// Variables

// var
// let
// const

// let number = 2510;

// let number2 = 34;
// console.log(number);

// console.log(number2);

// Assignment Operator
let a = 50;
let b = 25;
let c = 50;

// Arithmetic Operator

// console.log(a + b);
// console.log(a - b);
// console.log(a * b);
// console.log(a / b);
// console.log(a % b);

// console.log(3 ** 4);

// Comparision OP

// ==
// ===
console.log(a >= c);
